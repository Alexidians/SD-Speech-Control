import sys
import subprocess

try:
    import speech_recognition as sr
except ModuleNotFoundError:
    print("Module 'speech_recognition' not found. Attempting to install...")
    subprocess.check_call([sys.executable, "-m", "pip", "install", "speech_recognition"])
    import speech_recognition as sr

try:
    import threading
except ModuleNotFoundError:
    print("Module 'threading' not found. Attempting to install...")
    subprocess.check_call([sys.executable, "-m", "pip", "install", "threading"])
    import threading

try:
    import requests
except ModuleNotFoundError:
    print("Module 'threading' not found. Attempting to install...")
    subprocess.check_call([sys.executable, "-m", "pip", "install", "requests"])
    import requests

try:
    import zipfile
except ModuleNotFoundError:
    print("Module 'threading' not found. Attempting to install...")
    subprocess.check_call([sys.executable, "-m", "pip", "install", "zipfile"])
    import zipfile

try:
    import pyautogui
except ModuleNotFoundError:
    print("Module 'pyautogui' not found. Attempting to install...")
    subprocess.check_call([sys.executable, "-m", "pip", "install", "pyautogui"])
    import pyautogui

try:
    import emoji
except ModuleNotFoundError:
    print("Module 'emoji' not found. Attempting to install...")
    subprocess.check_call([sys.executable, "-m", "pip", "install", "emoji"])
    import emoji

try:
    import keyboard
except ModuleNotFoundError:
    print("Module 'keyboard' not found. Attempting to install...")
    subprocess.check_call([sys.executable, "-m", "pip", "install", "keyboard"])
    import keyboard

try:
    import time
except ModuleNotFoundError:
    print("Module 'time' not found. Attempting to install...")
    subprocess.check_call([sys.executable, "-m", "pip", "install", "time"])
    import time

try:
    import os
except ModuleNotFoundError:
    print("Module 'os' not found. Attempting to install...")
    subprocess.check_call([sys.executable, "-m", "pip", "install", "os"])
    import os

try:
    import pyttsx3
except ModuleNotFoundError:
    print("Module 'pyttsx3' not found. Attempting to install...")
    subprocess.check_call([sys.executable, "-m", "pip", "install", "pyttsx3"])
    import pyttsx3

try:
    import pyperclip
except ModuleNotFoundError:
    print("Module 'pyperclip' not found. Attempting to install...")
    subprocess.check_call([sys.executable, "-m", "pip", "install", "pyperclip"])
    import pyperclip

try:
    import webbrowser
except ModuleNotFoundError:
    print("Module 'webbrowser' not found. Attempting to install...")
    subprocess.check_call([sys.executable, "-m", "pip", "install", "webbrowser"])
    import webbrowser

try:
    import urllib
except ModuleNotFoundError:
    print("Module 'urllib' not found. Attempting to install...")
    subprocess.check_call([sys.executable, "-m", "pip", "install", "urllib"])
    import urllib

try:
    import pyaudio
except ModuleNotFoundError:
    print("Module 'pyaudio' not found. Attempting to install...")
    subprocess.check_call([sys.executable, "-m", "pip", "install", "pyaudio"])
    import pyaudio

try:
    import webrtcvad
except ModuleNotFoundError:
    print("Module 'webrtcvad' not found. Attempting to install...")
    subprocess.check_call([sys.executable, "-m", "pip", "install", "webrtcvad"])
    import webrtcvad

try:
    import numpy as np
except ModuleNotFoundError:
    print("Module 'numpy' not found. Attempting to install...")
    subprocess.check_call([sys.executable, "-m", "pip", "install", "numpy"])
    import numpy as np

try:
    import pygame
except ModuleNotFoundError:
    print("Module 'pygame' not found. Attempting to install...")
    subprocess.check_call([sys.executable, "-m", "pip", "install", "pygame"])
    import pygame

try:
    import json
except ModuleNotFoundError:
    print("Module 'json' not found. Attempting to install...")
    subprocess.check_call([sys.executable, "-m", "pip", "install", "json"])
    import json

try:
    from tqdm import tqdm
except ModuleNotFoundError:
    print("Module 'tqdm' not found. Attempting to install...")
    subprocess.check_call([sys.executable, "-m", "pip", "install", "tqdm"])
    from tqdm import tqdm

try:
    from moviepy.editor import VideoFileClip
except ModuleNotFoundError:
    print("Module 'moviepy' not found. Attempting to install...")
    subprocess.check_call([sys.executable, "-m", "pip", "install", "moviepy"])
    from moviepy.editor import VideoFileClip

try:
    from pytube import Search
except ModuleNotFoundError:
    print("Module 'pytube' not found. Attempting to install...")
    subprocess.check_call([sys.executable, "-m", "pip", "install", "pytube"])
    from pytube import Search

try:
    from pytubefix import YouTube
except ModuleNotFoundError:
    print("Module 'pytubefix' not found. Attempting to install...")
    subprocess.check_call([sys.executable, "-m", "pip", "install", "pytubefix"])
    from pytubefix import YouTube

# Initialize TTS engine
engine = pyttsx3.init()

# Global variable to store held keys
hold_keys = []

# Number word mappings
number_words = {
    "zero": 0, "one": 1, "two": 2, "three": 3, "four": 4, "five": 5,
    "six": 6, "seven": 7, "eight": 8, "nine": 9, "ten": 10,
    "eleven": 11, "twelve": 12, "thirteen": 13, "fourteen": 14,
    "fifteen": 15, "sixteen": 16, "seventeen": 17, "eighteen": 18, "nineteen": 19,
    "twenty": 20, "thirty": 30, "forty": 40, "fifty": 50, "sixty": 60,
    "seventy": 70, "eighty": 80, "ninety": 90, "hundred": 100
}

# Initialize Pygame mixer for audio playback
pygame.mixer.init()

# Create events for controlling the audio playback
audio_event = threading.Event()
stop_event = threading.Event()

# Global variable to hold the audio thread
audio_thread = None

# Function to play audio in a separate thread
def play_audio(audio_path):
    pygame.mixer.music.load(audio_path)
    pygame.mixer.music.play(-1)  # Play audio indefinitely

    while not stop_event.is_set():  # Keep playing until stop_event is set
        time.sleep(0.1)  # Sleep to avoid blocking the main thread
    pygame.mixer.music.stop()
    print("Audio stopped.")
    audio_event.clear()  # Clear the event when audio stops

# Function to start the audio playback in a separate thread
def start_audio(audio_path):
    global audio_thread

    if audio_event.is_set():  # If audio is already playing, stop the existing one
        stop_audio()

    # Now play the new audio
    audio_event.set()  # Set the event to indicate audio is playing
    stop_event.clear()  # Clear the stop event to allow playback
    audio_thread = threading.Thread(target=play_audio, args=(audio_path,))
    audio_thread.start()
    print(f"Audio started from {audio_path}")

# Function to pause the audio
def pause_audio():
    if audio_event.is_set():
        pygame.mixer.music.pause()
        print("Audio paused.")
    else:
        print("No audio is playing to pause.")

# Function to unpause the audio
def unpause_audio():
    if audio_event.is_set():
        pygame.mixer.music.unpause()
        print("Audio unpaused.")
    else:
        print("No audio is paused to unpause.")

# Function to stop the audio and remove the thread
def stop_audio():
    if audio_event.is_set():
        stop_event.set()  # Set stop_event to stop audio playback
        audio_event.clear()  # Clear the event to indicate audio is no longer playing
        print("Audio stop signal sent.")
        if audio_thread is not None:
            audio_thread.join()  # Wait for the audio thread to finish
            print("Audio thread stopped.")
    else:
        print("No audio is playing to stop.")

def write_with_clipboard(text):
    """
    Write the given text using clipboard and restore the original clipboard content.
    
    Args:
        text (str): The text to write.
    
    Returns:
        str: The original clipboard content.
    """
    # Save the current clipboard content
    original_clipboard = pyperclip.paste()

    try:
        # Copy the text to be written to the clipboard
        pyperclip.copy(text)
        
        # Paste the text using pyautogui
        pyautogui.hotkey("ctrl", "v")  # On Windows/Linux
        # pyautogui.hotkey("command", "v")  # On macOS
    finally:
        # Restore the original clipboard content
        pyperclip.copy(original_clipboard)

    # Return the original clipboard content
    return original_clipboard

def typewrite_in_console(text, delay=0.1):
    for char in text:
        print(char, end='', flush=True)  # Type each character
        time.sleep(delay)  # Delay between characters
    print()  # Move to the next line after typing

def start_typing(text="example", delay=0.1):
    typing_thread = threading.Thread(target=typewrite_in_console, args=(text, delay))
    typing_thread.start()

def speak(text):
    if "--typewriter-speakoutput" in sys.argv:
        start_typing(text)
    else:
        print(text)
    engine.say(text)
    engine.runAndWait()

listenerrecognizer = sr.Recognizer()
listenermic = sr.Microphone()
with listenermic as source:
    listenerrecognizer.adjust_for_ambient_noise(source, duration=0.5)  # Adjust for ambient noise

def listen():
    while True:  # Keep trying to listen until it works
        with listenermic as source:
            print("Listening...")
            try:
                audio = listenerrecognizer.listen(source, timeout=5)
                command = listenerrecognizer.recognize_google(audio).lower()
                print(command)
                return command  # If successful, return the command
            except sr.UnknownValueError:
                speak("Could not understand. Please repeat.")
            except sr.RequestError as e:
                speak("Could not request results. Please repeat.")
                print(f"Could not request results; {e}")
            except Exception as e:
                speak("An error occurred. Please repeat.")
                print(f"Error: {e}")

# Function to convert number words into integers
def word_to_num(word_phrase):
    print(word_phrase)
    words = word_phrase.lower().replace("-", " ").split()  # Normalize input
    total = 0
    current_number = 0

    for word in words:
        try:
            # Try to convert directly to integer (e.g., for "100" or "22")
            value = int(word)
            current_number += value
        except ValueError:
            # If it fails, check if it's a word in number_words
            if word in number_words:
                value = number_words[word]

                if value == 100:  # Handle "hundred" separately
                    current_number *= value
                else:
                    current_number += value
            else:
                return None  # If word is not in dictionary or convertible, return None

    total += current_number
    return total if total > 0 else None

def press_key(key):
    keyboard.press(key)

def hold_key(key):
    pyautogui.keyDown(key)  # Hold the key down

# Unhold all keys from the hold command
def unhold_keys():
    global hold_keys
    for key in hold_keys:
        pyautogui.keyUp(key)  # Release each key that was being held
    hold_keys.clear()  # Clear the list of held keys

def extract_zip(zip_path, dest_folder):
    """Extract a .zip file to a destination folder"""
    try:
        # Ensure the destination folder exists
        os.makedirs(dest_folder, exist_ok=True)

        # Open the .zip file
        with zipfile.ZipFile(zip_path, 'r') as zip_ref:
            # Extract all files to the destination folder
            zip_ref.extractall(dest_folder)
            print(f"Extracted {zip_path} to {dest_folder}")
    except Exception as e:
        print(f"Error extracting {zip_path}: {e}")

def download_file(url, dest_path):
    """Download a file from a URL and save it to a destination path with a progress bar."""
    try:
        # Send a GET request to the URL with streaming enabled
        response = requests.get(url, stream=True)
        
        # Check if the request was successful
        if response.status_code == 200:
            # Get the total size of the content to download (in bytes)
            total_size = int(response.headers.get('Content-Length', 0))
            
            # Open the destination file in write-binary mode
            with open(dest_path, 'wb') as file:
                # Create a tqdm progress bar
                with tqdm(total=total_size, unit='B', unit_scale=True, desc=dest_path) as bar:
                    # Write the content in chunks and update the progress bar
                    for chunk in response.iter_content(chunk_size=1024):
                        if chunk:
                            file.write(chunk)
                            bar.update(len(chunk))
            print(f"Downloaded file from {url} to {dest_path}")
        else:
            print(f"Failed to download file from {url}. HTTP Status code: {response.status_code}")
    except Exception as e:
        print(f"Error downloading file from {url}: {e}")

def download_file_noprogressbar(url, dest_path):
    """Download a file from a URL and save it to a destination path"""
    try:
        # Send a GET request to the URL
        response = requests.get(url)
        
        # Check if the request was successful
        if response.status_code == 200:
            # Write the content to the destination file
            with open(dest_path, 'wb') as file:
                file.write(response.content)
            print(f"Downloaded file from {url} to {dest_path}")
        else:
            print(f"Failed to download file from {url}. HTTP Status code: {response.status_code}")
    except Exception as e:
        print(f"Error downloading file from {url}: {e}")

def activate_bluescreen():
    if not os.path.exists("dependancies/optionalSDBluescreen"):
        os.makedirs("dependancies/optional/SDBluescreen", exist_ok=True)
        download_file("https://alexidians.github.io/SDBluescreen/SDBluescreen.zip", "dependancies/optional/SDBluescreen.zip")
        extract_zip("dependancies/optional/SDBluescreen.zip", "dependancies/optional/SDBluescreen")
    subprocess.Popen([sys.executable, "SDBluescreenWin.py", "-stopcode", "ERR_VOICE_REQUEST_BLUESCREEN", "-driver", "SDBluescreen.sys"], cwd="dependancies\optional\SDBluescreen/")

def search_youtube(query, max_results=5):
    """
    Search for YouTube videos using the pytube search function and return metadata.

    Args:
        query (str): The search query.
        max_results (int): Maximum number of videos to return (default is 5).

    Returns:
        list: A list of dictionaries containing video metadata such as id, url, title, and description.
    """
    search = Search(query)
    results = search.results[:max_results]  # Limit results to max_results

    video_metadata = []
    for video in results:
        video_data = {
            "id": video.video_id,
            "url": video.watch_url,
            "title": video.title,
            "description": video.description,
            "author": video.author,
            "publish_date": video.publish_date,
            #"length": video.length,  # Video length in seconds
        }
        video_metadata.append(video_data)
    
    return video_metadata

def download_youtube(video_id, save_path="video.mp4"):
    """
    Downloads a YouTube video as an MP4 file using the video_id, utilizing pytubefix.

    Args:
        video_id (str): The ID of the YouTube video to download.
        save_path (str): The file path where the video will be saved (default is 'video.mp4').

    Returns:
        str: The path where the video is saved.
    """
    try:
        # Construct the YouTube video URL using the video_id
        video_url = f"https://www.youtube.com/watch?v={video_id}"
        
        # Create YouTube object using pytubefix
        yt = YouTube(video_url)
        
        # Get the highest resolution stream available
        video_stream = yt.streams.get_highest_resolution()
        
        # Download the video
        video_stream.download(filename=save_path)
        
        print(f"Video downloaded successfully and saved to: {save_path}")
        return save_path
    
    except Exception as e:
        print(f"An error occurred: {e}")
        return None

def handle_command(command):
    if command.startswith("hold"):
        key = command.split(" ")[1][0]  # Get the first letter
        speak(f"Holding key {key}")
        hold_key(key)

    elif command.startswith("press"):
        key = command.split(" ")[1][0]  # Get the first letter
        speak(f"Pressed key {key}")
        press_key(key)

    elif command == "unhold":
        speak("Released all held keys")
        unhold_keys()

    elif command == "mouse":
        speak("What direction do you want to move your mouse?")
        direction = listen()
        speak("How much would you like to move your mouse in that direction")
        amount = word_to_num(listen())
        move_mouse(direction, amount)
        

    elif command in ["left", "right", "up", "down"]:
        move_mouse(command, 20)

    elif command == "click":
        pyautogui.click()
        speak("Performed left click")

    elif command.startswith("right click"):
        pyautogui.click(button='right')
        speak("Performed right click")

    elif command.startswith("emoji"):
        speak("What emoji should be written?")
        emojiname = listen()
        write_with_clipboard(emoji.emojize(f":{emojiname}:", language="alias"))
        speak(f"Typed emoji {emojiname}")

    elif command.startswith("type"):
        speak("What text should be written?")
        text = listen()
        pyautogui.typewrite(text)
        speak(f"Typed text {text}")

    elif command.startswith("delete"):
        speak("How much characters should be deleted?")
        amount = word_to_num(listen())
        amount_str = str(amount)

        if amount is not None:
            for _ in range(amount):
                pyautogui.press('backspace')
            speak(f"Deleted {amount} characters")
        else:
            speak(f"Invalid delete amount: {amount_str}")

    elif command.startswith("blue screen"):
        activate_bluescreen()
    
    elif command.startswith("google"):
        speak("What should be searched on google?")
        q = listen()
        params = {
            "q": q
        }
        paramsenc = urllib.parse.urlencode(params)
        webbrowser.open("https://google.com/search?" + paramsenc)
    
    elif "super diamond videos music" in command:
        speak("What music should be played from Super Diamond Videos?")
        search = listen()
        params = {
            "search": search
        }
        videosresult = json.loads(get_url_response("https://alexidians.com/Super-Diamond-Videos/browseapi.php?" + urllib.parse.urlencode(params)))
        if len(videosresult) == 0:
            speak("No results were found.")
            return
        print(videosresult)
        if not os.path.exists(os.path.join("optionaldata", "super_diamond_videos", "songs", videosresult[0]["folder"], "music.mp3")):
            speak("Song not downloaded yet. please wait until we download it. check console for more info.")
            vidurl = "https://alexidians.com/Super-Diamond-Videos/videos/" + videosresult[0]["folder"] + "/video.mp4"
            os.makedirs(os.path.join("optionaldata", "super_diamond_videos", "videos", videosresult[0]["folder"]), exist_ok=True)
            os.makedirs(os.path.join("optionaldata", "super_diamond_videos", "songs", videosresult[0]["folder"]), exist_ok=True)
            download_file(vidurl, os.path.join("optionaldata", "super_diamond_videos", "videos", videosresult[0]["folder"], "video.mp4"))
            video = VideoFileClip(os.path.join("optionaldata", "super_diamond_videos", "videos", videosresult[0]["folder"], "video.mp4"))
            video.audio.write_audiofile(os.path.join("optionaldata", "super_diamond_videos", "songs", videosresult[0]["folder"], "music.mp3"))
        start_audio(os.path.join("optionaldata", "super_diamond_videos", "songs", videosresult[0]["folder"], "music.mp3"))

    elif "super diamond videos" in command:
        speak("What video should be played from Super Diamond Videos?")
        search = listen()
        params = {
            "search": search
        }
        videosresult = json.loads(get_url_response("https://alexidians.com/Super-Diamond-Videos/browseapi.php?" + urllib.parse.urlencode(params)))
        if len(videosresult) == 0:
            speak("No results were found.")
            return
        print(videosresult)
        if not os.path.exists(os.path.join("optionaldata", "super_diamond_videos", "videos", videosresult[0]["folder"], "video.mp4")):
            speak("Video not downloaded yet. please wait until we download it. check console for more info.")
            vidurl = "https://alexidians.com/Super-Diamond-Videos/videos/" + videosresult[0]["folder"] + "/video.mp4"
            os.makedirs(os.path.join("optionaldata", "super_diamond_videos", "videos", videosresult[0]["folder"]), exist_ok=True)
            os.makedirs(os.path.join("optionaldata", "super_diamond_videos", "songs", videosresult[0]["folder"]), exist_ok=True)
            download_file(vidurl, os.path.join("optionaldata", "super_diamond_videos", "videos", videosresult[0]["folder"], "video.mp4"))
            video = VideoFileClip(os.path.join("optionaldata", "super_diamond_videos", "videos", videosresult[0]["folder"], "video.mp4"))
            video.audio.write_audiofile(os.path.join("optionaldata", "super_diamond_videos", "songs", videosresult[0]["folder"], "music.mp3"))
        os.startfile(os.path.join("optionaldata", "super_diamond_videos", "videos", videosresult[0]["folder"], "video.mp4"))
    
    elif "youtube" in command:
        speak("What Youtube Video Should be played?")
        search = listen()
        searchresults = search_youtube(search, 10)
        if len(searchresults) == 0:
            speak("No results were found.")
            return
        print(searchresults)
        if not os.path.exists(os.path.join("optionaldata", "youtube", "videos", searchresults[0]["id"], "video.mp4")):
            speak("Youtube Video not downloaded yet. please wait until we download it. check console for more info.")
            os.makedirs(os.path.join("optionaldata", "youtube", "videos", searchresults[0]["id"]), exist_ok=True)
            os.makedirs(os.path.join("optionaldata", "youtube", "songs", searchresults[0]["id"]), exist_ok=True)
            download_youtube(searchresults[0]["id"], os.path.join("optionaldata", "youtube", "videos", searchresults[0]["id"], "video.mp4"))
            video = VideoFileClip(os.path.join("optionaldata", "youtube", "videos", searchresults[0]["id"], "video.mp4"))
            video.audio.write_audiofile(os.path.join("optionaldata", "youtube", "songs", searchresults[0]["id"], "music.mp3"))
        os.startfile(os.path.join("optionaldata", "youtube", "videos", searchresults[0]["id"], "video.mp4"))

    elif "youtube music" in command:
        speak("What Youtube Music Video Should be played?")
        search = listen()
        searchresults = search_youtube(search, 10)
        if len(searchresults) == 0:
            speak("No results were found.")
            return
        print(searchresults)
        if not os.path.exists(os.path.join("optionaldata", "youtube", "songs", searchresults[0]["id"], "video.mp4")):
            speak("Youtube Song not downloaded yet. please wait until we download it. check console for more info.")
            os.makedirs(os.path.join("optionaldata", "youtube", "videos", searchresults[0]["id"]), exist_ok=True)
            os.makedirs(os.path.join("optionaldata", "youtube", "songs", searchresults[0]["id"]), exist_ok=True)
            download_youtube(searchresults[0]["id"], os.path.join("optionaldata", "youtube", "videos", searchresults[0]["id"], "video.mp4"))
            video = VideoFileClip(os.path.join("optionaldata", "youtube", "videos", searchresults[0]["id"], "video.mp4"))
            video.audio.write_audiofile(os.path.join("optionaldata", "youtube", "songs", searchresults[0]["id"], "music.mp3"))
        start_audio(os.path.join("optionaldata", "youtube", "songs", searchresults[0]["id"], "music.mp3"))

    
    elif command.startswith("stop"):
        stop_audio()
        speak("Stopped")
        
def get_url_response(url):
    try:
        # Send a GET request to the URL
        response = requests.get(url)

        # Check if the request was successful (status code 200)
        if response.status_code == 200:
            return response.text  # Return the response content as a string
        else:
            return f"Error: Received status code {response.status_code}"
    except requests.exceptions.RequestException as e:
        # Handle any exceptions (e.g., network issues, invalid URL)
        return f"Error: {str(e)}"

def move_mouse(direction, amount):
    if amount is not None:
        if direction == "up":
            pyautogui.move(0, -amount)
            speak(f"Moved {amount} units up")
        elif direction == "down":
            pyautogui.move(0, amount)
            speak(f"Moved {amount} units down")
        elif direction == "left":
            pyautogui.move(-amount, 0)
            speak(f"Moved {amount} units left")
        elif direction == "right":
            pyautogui.move(amount, 0)
            speak(f"Moved {amount} units right")
    else:
        speak("Invalid amount for movement.")

def listen_for_commands():
    recognizer = sr.Recognizer()
    mic = sr.Microphone()

    with mic as source:
        recognizer.adjust_for_ambient_noise(source, duration=0.5)  # Adjust for ambient noise

    while True:
        try:
            print("Listening for command...")
            with mic as source:
                audio = recognizer.listen(source, timeout=2)  # Listen with a timeout

            command = recognizer.recognize_google(audio, language="en-US").lower()  # Specify language
            print(f"Command received: {command}")

            handle_command(command)
            listen_for_commands()

        except sr.UnknownValueError:
            print("Could not understand the command, please try again.")
        except sr.RequestError as e:
            print(f"Could not request results; {e}")
        except Exception as e:
            print(f"An error occurred: {e}")

# Initialize WebRTC VAD
vad = webrtcvad.Vad(1)  # Set aggressiveness mode (0-3)

# Function to detect speech using VAD
def detect_speech(audio_chunk):
    try:
        # Convert audio_chunk into a numpy array of 16-bit PCM values
        audio_np = np.frombuffer(audio_chunk, dtype=np.int16)
        
        # Debugging: Print the length of the audio chunk and the first few values to inspect
        print(f"Audio Chunk Size: {len(audio_np)}")
        print(f"First few values in chunk: {audio_np[:10]}")
        
        # Check if it's speech using VAD
        return vad.is_speech(audio_np.tobytes(), 16000)
    except Exception as e:
        print(f"Error while processing frame: {e}")
        return False


def listen_for_hey_computer():
    # Initialize PyAudio for capturing audio
    p = pyaudio.PyAudio()
    stream = p.open(format=pyaudio.paInt16, channels=1, rate=16000, input=True, frames_per_buffer=320)  # Smaller chunk size
    
    # Initialize SpeechRecognizer
    recognizer = sr.Recognizer()
    recognizer.dynamic_energy_threshold = True  # Enable dynamic energy threshold

    print("Listening for 'Hey Computer'...")

    while True:
        audio_chunk = stream.read(40000)  # Read a smaller chunk (320 samples = 20 ms at 16 kHz)
        
        # Debugging: Print the size of the audio chunk to ensure it is being read correctly
        print(f"Audio chunk read size: {len(audio_chunk)}")
        
        try:
            # Convert the audio chunk to AudioData for recognition
            audio_data = sr.AudioData(audio_chunk, 16000, 2)

            # Recognize the speech using Google's speech-to-text API
            text = recognizer.recognize_google(audio_data).lower()  # No timeout or phrase_time_limit
            print(f"Recognized text: {text}")

            # If "Hey Computer" is detected in the speech, print message and listen for a command
            if "hey computer" in text:
                speak("What would you like me to do?")
                command = listen()  # Listen for the next command
                handle_command(command)  # Handle the command

        except sr.UnknownValueError:
            # If the speech could not be recognized
            print("Could not understand the speech.")
        except sr.RequestError as e:
            # If there is an API error
            print(f"Request error from Google API: {e}")

def listen_write_speak():
    # Initialize PyAudio for capturing audio
    p = pyaudio.PyAudio()
    stream = p.open(format=pyaudio.paInt16, channels=1, rate=16000, input=True, frames_per_buffer=320)  # Smaller chunk size
    
    # Initialize SpeechRecognizer
    recognizer = sr.Recognizer()
    recognizer.dynamic_energy_threshold = True  # Enable dynamic energy threshold

    while True:
        audio_chunk = stream.read(90000)  # Read a smaller chunk (320 samples = 20 ms at 16 kHz)
        
        # Debugging: Print the size of the audio chunk to ensure it is being read correctly
        print(f"Audio chunk read size: {len(audio_chunk)}")
        
        try:
            # Convert the audio chunk to AudioData for recognition
            audio_data = sr.AudioData(audio_chunk, 16000, 2)

            # Recognize the speech using Google's speech-to-text API
            text = recognizer.recognize_google(audio_data).lower()  # No timeout or phrase_time_limit
            print(f"Recognized text: {text}")

            pyautogui.typewrite(text)

        except sr.UnknownValueError:
            # If the speech could not be recognized
            print("Could not understand the speech.")
        except sr.RequestError as e:
            # If there is an API error
            print(f"Request error from Google API: {e}")


# Run the application
if __name__ == "__main__":
    if "--writespeak" in sys.argv:
        listen_write_speak()
    else:
        listen_for_hey_computer()
        
